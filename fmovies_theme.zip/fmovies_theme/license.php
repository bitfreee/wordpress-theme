<?php
/**
 * fmovie license
 *
 * @package fmovie
 */


/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

//Customer: mwise@werviral.com
//your users unique license key you can get it here https://fr0zen.store/contact/
define	('FMOVIES_LICENSE', '1010-2121-3232-4344');
